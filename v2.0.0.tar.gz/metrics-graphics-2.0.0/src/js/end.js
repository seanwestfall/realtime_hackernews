if (typeof define === "function" && define.amd) define(MG);
else if (typeof module === "object" && module.exports) module.exports = MG;
window.MG = MG;
